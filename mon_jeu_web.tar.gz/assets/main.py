import pygame
import random
import asyncio

# Initialisation
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

# Surfaces et Polices
paint_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
paint_surface.fill((255, 255, 255, 255)) 
font = pygame.font.SysFont("Arial", 40)

# Constantes
SPEED_POWERUP = 0
EXPLOSION_POWERUP = 1

class Entity:
    def __init__(self, x, y, color, speed):
        self.rect = pygame.Rect(x, y, 20, 20)
        self.color = color
        self.base_speed = speed
        self.speed_boost_time = 0

    def keep_in_bounds(self):
        self.rect.clamp_ip(screen.get_rect())

    def get_dynamic_speed(self):
        # Sécurité pour éviter erreur si hors limite
        x, y = self.rect.centerx, self.rect.centery
        if not (0 <= x < WIDTH and 0 <= y < HEIGHT): return self.base_speed
        
        pixel_color = paint_surface.get_at((x, y))
        if pixel_color[:3] == self.color:
            return self.base_speed * 1.5 
        elif pixel_color[:3] != (255, 255, 255) and pixel_color[:3] != (0, 0, 0, 0):
            return self.base_speed * 0.5 
        return self.base_speed 

    def draw_with_shadow(self):
        shadow_rect = self.rect.copy()
        shadow_rect.x += 4
        shadow_rect.y += 4
        pygame.draw.rect(paint_surface, (50, 50, 50, 100), shadow_rect)
        color_alpha = (self.color[0], self.color[1], self.color[2], 200)
        pygame.draw.rect(paint_surface, color_alpha, self.rect)

class Player(Entity):
    def update(self, keys):
        current_speed = self.get_dynamic_speed()
        if keys[pygame.K_LEFT]: self.rect.x -= current_speed
        if keys[pygame.K_RIGHT]: self.rect.x += current_speed
        if keys[pygame.K_UP]: self.rect.y -= current_speed
        if keys[pygame.K_DOWN]: self.rect.y += current_speed
        self.keep_in_bounds()
        self.draw_with_shadow()

class Enemy(Entity):
    def __init__(self, x, y, color, speed):
        super().__init__(x, y, color, speed)
        self.vel_x = random.choice([-speed, speed])
        self.vel_y = random.choice([-speed, speed])

    def update(self):
        current_speed = self.get_dynamic_speed()
        if random.random() < 0.05:
            self.vel_x = random.choice([-current_speed, current_speed])
            self.vel_y = random.choice([-current_speed, current_speed])
        self.rect.x += self.vel_x
        self.rect.y += self.vel_y
        if self.rect.left <= 0 or self.rect.right >= WIDTH: self.vel_x *= -1
        if self.rect.top <= 0 or self.rect.bottom >= HEIGHT: self.vel_y *= -1
        self.keep_in_bounds()
        self.draw_with_shadow()

class PowerUp:
    def __init__(self):
        self.type = random.choice([SPEED_POWERUP, EXPLOSION_POWERUP])
        self.rect = pygame.Rect(random.randint(50, WIDTH - 50), random.randint(50, HEIGHT - 50), 10, 10)
        self.color = (255, 255, 0) if self.type == SPEED_POWERUP else (0, 0, 0)

    def draw(self, surface):
        pygame.draw.circle(surface, self.color, self.rect.center, 10)

    def apply_effect(self, entity):
        if self.type == SPEED_POWERUP:
            entity.base_speed = 8
            entity.speed_boost_time = 300
        elif self.type == EXPLOSION_POWERUP:
            color_alpha = (entity.color[0], entity.color[1], entity.color[2], 150)
            pygame.draw.circle(paint_surface, color_alpha, entity.rect.center, 50)

# Boucle principale asynchrone pour le Web
async def main():
    player = Player(100, 100, (255, 0, 0), 4)
    enemy = Enemy(700, 500, (0, 0, 255), 4)
    powerups = []
    
    time_left = 120 * 60 
    game_over = False
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False
            # Recharge du jeu si Game Over
            if game_over and event.type == pygame.KEYDOWN: 
                return await main() 

        if not game_over:
            if time_left > 0:
                time_left -= 1
                player.update(pygame.key.get_pressed())
                enemy.update()
                
                # Gestion des PowerUps
                if random.random() < 0.01: powerups.append(PowerUp())
                for p in powerups[:]:
                    if player.rect.colliderect(p.rect): p.apply_effect(player); powerups.remove(p)
                    elif enemy.rect.colliderect(p.rect): p.apply_effect(enemy); powerups.remove(p)
            else:
                game_over = True
        
        # Rendu
        screen.fill((255, 255, 255))
        screen.blit(paint_surface, (0, 0))
        for p in powerups: p.draw(screen)
        
        if not game_over:
            timer_text = font.render(f"Temps: {time_left // 60}", True, (0, 0, 0))
            screen.blit(timer_text, (10, 10))
        else:
            res_text = font.render("JEU TERMINE - Appuie sur une touche", True, (0, 0, 0))
            screen.blit(res_text, (80, 250))
        
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0) # Le secret pour le Web

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())